﻿
#TO DO mappen en shares misschien in basisinstellingen

function basisinstellingen()
{
    do
    {
        Import-Module Z:\scripting\basissettings.psm1
        Clear-Host
        Write-Host "keuzemenu:"
        Write-Host "`t1. naamwijzigen"
        Write-Host "`t2. interfaces wijzigen"
        Write-Host "kies 0 om terug te keren"

        [int]$keuze = Read-Host "Wat wilt u instellen?"

        if ($keuze -match '[0-2]') 
        {
            switch ($keuze) 
            {
                1 
                {
                    [string]$restartkeuze = Read-Host "Wilt u na deze wijzigingen automatisch herstarten? (y/n)"
                    naamwijziging -restartkeuze $restartkeuze
                }
                2 
                {
                    interfaceswijzigingen
                }
            }
        } 
        else 
        {
            Write-Host "Ongeldige keuze. De enige geldige keuzes zijn 0, 1 en 2. Druk op Enter om door te gaan." -ForegroundColor Red
            Read-Host
        }
    } while ($keuze -ne 0)
}
Export-ModuleMember basisinstellingen

function domain_configuratie()
{
    do
    {
        Import-Module Z:\scripting\domaininstalatie.psm1
        Clear-Host
        Write-Host "keuzemenu:"
        Write-Host "`t1. Domain maken"
        Write-Host "`t2. OU's aanmaken"
        Write-Host "`t3. Security groepen aanmaken"
        Write-Host "kies 0 om terug te keren"

        [int]$keuze = Read-Host "Wat wilt u instellen?"

        if ($keuze -match '[0-3]') 
        {
            switch ($keuze)
            {
                1
                {
                    [string]$restartkeuze = Read-Host "Wilt u na deze wijzigingen automatisch herstarten? (y/n)"
                    $wachtwoord = Read-Host "Wat wilt u gebruiken als wachtwoord" -AsSecureString
                    domaininstalatie -password $wachtwoord -restartkeuze $restartkeuze
                }
                2
                {
                    ous-aanmaken
                }
                3
                {
                    Goups-aanmaken
                }
            }
        } 
        else 
        {
            Write-Host "Ongeldige keuze. De enige geldige keuzes zijn 0, 1, 2 en 3. Druk op Enter om door te gaan." -ForegroundColor Red
            Read-Host
        }
    } while ($keuze -ne 0)
}
Export-ModuleMember domain_configuratie

function mappen_en_shares()
{
    do {
    Import-Module Z:\scripting\mappen-en-shares.psm1
    Clear-Host
    Write-Host "keuzemenu:"
    Write-Host "`t1. Mappen structuur aanmaken"
    Write-Host "`t2. Shares aanmaken"
    Write-Host "kies 0 om terug te keren"

    [int]$keuze = Read-Host "Wat wilt u instellen?"

    if ($keuze -match '[0-2]') {
        switch ($keuze) {
            1 {
                mappenstructuur
            }
            2 {
                shares
            }
        }
    } else {
        Write-Host "Ongeldige keuze. De enige geldige keuzes zijn 0, 1 en 2. Druk op Enter om door te gaan." -ForegroundColor Red
        Read-Host
    }
} while ($keuze -ne 0)
}
Export-ModuleMember mappen_en_shares