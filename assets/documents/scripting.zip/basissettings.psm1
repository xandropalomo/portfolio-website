﻿
# TO DO interfaces wijzigen 2 exact de zelfde code dit veranderen naar 1 keer!!!
# en als de mac addressen verkeerd zijn krijg de gebruiker error haal die error weg en zeg dat de mac addressen niet gevonden zijn

function naamwijziging {
    <#
    .SYNOPSIS
        Deze functie wijzigt de naam van de computer op basis van instellingen in een XML-bestand en logt de wijziging.

    .DESCRIPTION
        Deze functie leest de instellingen uit een XML-bestand en wijzigt de computernaam van de server of het werkstation, afhankelijk van de Windows-editie.
        Het logt de wijziging naar een logbestand.

    .PARAMETER restartkeuze
        Geeft aan of de computer automatisch moet worden herstart na het wijzigen van de naam.

    .EXAMPLE
        naamwijziging -restartkeuze 'y'
        Wijzigt de computernaam en start de computer automatisch opnieuw op.

    .EXAMPLE
        naamwijziging -restartkeuze 'n'
        Wijzigt de computernaam en vraagt om handmatige herstartverificatie.

    #>

    [cmdletbinding()]
    param (
        [parameter(Mandatory=$true, HelpMessage= "Wilt u automatisch herstarten? (y/n)")]
        [string]$restartkeuze
    )

    # Het pad naar het XML-bestand met instellingen
    $xmlpath = "Z:\scripting\settings\instellingen.xml"

    # Probeer het XML-bestand in te lezen en log een fout als dit mislukt
    try 
    {
        [xml]$xml = Get-Content -Path $xmlpath -ErrorAction Stop
    } 
    catch 
    {
        Log-Message "ERROR: Kon XML-bestand niet lezen: $_"
        return
    }

    # Windows-editie controleren
    $windowsedition = Get-WindowsEdition -online

    try 
    {
        if ($windowsedition.Edition -eq "ServerStandard") 
        {
            # Servernaam wijzigen indien nodig
            $servernaam = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "servernaam" }
        
            if ($servernaam.'#text' -ne $env:COMPUTERNAME) 
            {
                Rename-Computer -NewName $servernaam.'#text' -Force
                
                # Wijziging loggen naar logbestand
                Log-Message "######    Servernaam wijziging    ######"
                Log-Message "Servernaam gewijzigd naar $($servernaam.innertext)"
                Log-Message "######    Eind servernaam wijziging    ######"
            
                Write-Host "Servernaam is gewijzigd"
            } 
            else 
            {
                Write-Host "Naam is al gewijzigd"
            }
        } 
        else 
        {
            # Werkstationnaam wijzigen
            $workstationnaam = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "workstation_naam" }
            Rename-Computer -NewName $workstationnaam.innertext -Force
            
            # Wijziging loggen naar logbestand
            Log-Message "######    Werkstationnaam wijziging    ######"
            Log-Message "Werkstationnaam gewijzigd naar $($workstationnaam.innertext) op $(Get-Date)"
            Log-Message "######    Eind werkstationnaam wijziging    ######"
        }
    } 
    catch 
    {
        # Log een foutmelding als er een uitzondering optreedt bij het wijzigen van de computernaam
        Log-Message "ERROR: Fout bij het wijzigen van de computernaam: $_"
        return
    }

    # Melding over de gewijzigde naam en de noodzaak om opnieuw op te starten
    if ($windowsedition.Edition -eq "ServerStandard") 
    {
        $newName = $servernaam.innertext
    } 
    else 
    {
        $newName = $workstationnaam.innertext
    }
    Write-Host "Naam is gewijzigd naar $newName. Herstart is nodig."

    # Herstarten, indien gekozen
    if ($restartkeuze -eq "y") 
    {
        Write-Host "Herstarten in 10 seconden..."
        Start-Sleep -Seconds 10
        Restart-Computer
    } 
    elseif ($restartkeuze -eq "n") 
    {
        Write-Host "U zal handmatig moeten herstarten" -ForegroundColor Green
        Write-Host "Druk op Enter om te verifieren"
        Read-Host
    }
}

Export-ModuleMember -Function naamwijziging



function interfaceswijzigingen {
    <#
    .SYNOPSIS
        Deze functie wijzigt de netwerkinterfaces van de computer op basis van instellingen in een XML-bestand en logt de wijzigingen.

    .DESCRIPTION
        Deze functie leest de netwerkinterface-instellingen uit een XML-bestand en past deze toe op de WAN- en LAN-netwerkkaarten van de computer.
        Het logt de wijzigingen naar een logbestand.

    .EXAMPLE
        interfaceswijzigingen
        Voert de wijzigingen in netwerkinterfaces uit zoals gespecificeerd in het XML-bestand.

    #>

    $xmlpath =  "Z:\scripting\settings\instellingen.xml"

    [xml]$xml = Get-Content -Path $xmlpath -ErrorAction Stop

    # Alle instellingen van de XML file ophalen
    $wanipaddress = $xml.objs.obj.MS.S | Where-Object {$_.N -eq "Wan_ip_adress"}
    $wanmacaddress = $xml.Objs.Obj.MS.S | where-object {$_.N -eq "Wan_mac_adress"}
    $WanipDefaultgateway = $xml.Objs.Obj.MS.S | where-object {$_.N -eq "Wan_ip_Default_gateway"}
    $Wanipnetmask = $xml.Objs.Obj.MS.S | where-object {$_.N -eq "Wan_ip_netmask"}
    $Wanipdns = $xml.Objs.Obj.MS.S | where-object {$_.N -eq "Wan_ip_dns"}
    $Lanipadress = $xml.objs.obj.MS.S | Where-Object {$_.N -eq "Lan_ip_adress"}
    $Lanmacadress = $xml.objs.obj.MS.S | Where-Object {$_.N -eq "Lan_mac_adress"}
    $LANipnetmask = $xml.objs.obj.MS.S | Where-Object {$_.N -eq "LAN_ip_netmask"}

    # WAN-netwerkkaart instellingen toepassen
    try 
    {
        # WAN netwerkadapter ophalen op basis van het MAC-adres
        $networkAdapter = Get-NetAdapter -Physical | Where-Object {$_.MacAddress -eq $wanmacaddress.'#text'}
        if ($networkAdapter -ne $null) 
        {
            # Naam van de netwerkkaart aanpassen naar "Wan"
            Rename-NetAdapter -Name $networkAdapter.Name -NewName "Wan"

            # Bestaand IP-adres controleren en indien nodig verwijderen
            $existingIPAddress = Get-NetIPAddress -InterfaceIndex $networkAdapter.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue
            if ($existingIPAddress) 
            {
                Remove-NetIPAddress -InterfaceIndex $networkAdapter.InterfaceIndex -AddressFamily IPv4 -Confirm:$false
            }

            # Bestaande standaardgateway controleren en indien nodig verwijderen
            $existingDefaultGateway = Get-NetRoute -InterfaceIndex $networkAdapter.InterfaceIndex -DestinationPrefix 0.0.0.0/0 -ErrorAction SilentlyContinue
            if ($existingDefaultGateway) 
            {
                Remove-NetRoute -InterfaceIndex $networkAdapter.InterfaceIndex -DestinationPrefix 0.0.0.0/0 -Confirm:$false
            }

            # Nieuw IP-adres en standaardgateway toewijzen
            New-NetIPAddress -IPAddress $wanipaddress.'#text' -InterfaceIndex $networkAdapter.InterfaceIndex -PrefixLength $Wanipnetmask.'#text' -DefaultGateway $WanipDefaultgateway.'#text'
            # DNS-serveradressen instellen
            Set-DnsClientServerAddress -InterfaceIndex $networkAdapter.InterfaceIndex -ServerAddresses $Wanipdns.'#text'

            # Wijzigingen loggen
            $networkAdapter = Get-NetAdapter -Physical | Where-Object {$_.MacAddress -eq $wanmacaddress.'#text'}
            Log-Message "######    WAN interface    ######"
            Log-Message "naam van netwerkkaart veranderd naar $($networkAdapter.Name)"
            Log-Message "WAN ip gewijzigd naar $($wanipaddress.innertext)"
            Log-Message "WAN defaultgateway gewijzigd naar $($WanipDefaultgateway.innertext)"
            Log-Message "######    eind WAN interface    ######"
        } 
        else 
        {
            # Log een foutmelding als de WAN-netwerkadapter niet gevonden is
            Log-Message "ERROR: WAN netwerkadapter met MAC-adres $($wanmacaddress.'#text') niet gevonden."
        }
    } 
    catch 
    {
        # Log een foutmelding als er een uitzondering optreedt bij het instellen van de WAN-netwerkadapter
        Log-Message "ERROR: Fout bij het instellen van WAN-netwerkadapter: $_"
    }

    # LAN-netwerkkaart instellingen toepassen
    try 
    {
        # LAN netwerkadapter ophalen op basis van het MAC-adres
        $networkAdapter = Get-NetAdapter -Physical | Where-Object {$_.MacAddress -eq $Lanmacadress.'#text'}
        if ($networkAdapter -ne $null) 
        {
            # Naam van de netwerkkaart aanpassen naar "Lan"
            Rename-NetAdapter -Name $networkAdapter.Name -NewName "Lan"

            # Bestaand IP-adres controleren en indien nodig verwijderen
            $existingIPAddress = Get-NetIPAddress -InterfaceIndex $networkAdapter.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue
            if ($existingIPAddress) 
            {
                Remove-NetIPAddress -InterfaceIndex $networkAdapter.InterfaceIndex -AddressFamily IPv4 -Confirm:$false
            }

            # Nieuw IP-adres toewijzen
            New-NetIPAddress -IPAddress $Lanipadress.'#text' -InterfaceIndex $networkAdapter.InterfaceIndex -PrefixLength $LANipnetmask.'#text'
            # DNS-serveradres instellen op localhost (127.0.0.1)
            Set-DnsClientServerAddress -InterfaceIndex $networkAdapter.InterfaceIndex -ServerAddresses 127.0.0.1

            # Wijzigingen loggen
            $networkAdapter = Get-NetAdapter -Physical | Where-Object {$_.MacAddress -eq $Lanmacadress.'#text'}
            Log-Message "######    LAN interface    ######"
            Log-Message "naam van netwerkkaart veranderd naar $($networkAdapter.Name)"
            Log-Message "LAN ip gewijzigd naar $($Lanipadress.innertext)"
            Log-Message "######    eind LAN interface    ######"
        } 
        else 
        {
            # Log een foutmelding als de LAN-netwerkadapter niet gevonden is
            Log-Message "ERROR: LAN netwerkadapter met MAC-adres $($Lanmacadress.'#text') niet gevonden."
        }
    } 
    catch 
    {
        # Log een foutmelding als er een uitzondering optreedt bij het instellen van de LAN-netwerkadapter
        Log-Message "ERROR: Fout bij het instellen van LAN-netwerkadapter: $_"
    }

    # Bevestigingsberichten weergeven
    Write-Host "WAN instellingen gewijzigd"
    Write-Host "LAN instellingen gewijzigd"

    # Gebruiker vragen om op enter te drukken om verder te gaan
    Write-Host "druk op enter om verder te gaan" -BackgroundColor Green
    Read-Host
}

# Exporteer de functie zodat deze buiten het script kan worden gebruikt
Export-ModuleMember -Function interfaceswijzigingen
