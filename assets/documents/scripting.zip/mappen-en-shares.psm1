﻿
function mappenstructuur {
    <#
    .SYNOPSIS
        Deze functie creëert een mappenstructuur op basis van paden opgegeven in een tekstbestand.

    .DESCRIPTION
        Deze functie leest de paden uit een tekstbestand en maakt vervolgens de corresponderende mappen aan als deze niet al bestaan. Alle acties worden gelogd naar een logbestand.

    .PARAMETER None
        Er zijn geen parameters nodig voor deze functie.

    .EXAMPLE
        mappenstructuur
        Creëert de mappenstructuur zoals gespecificeerd in het tekstbestand en logt alle acties naar een logbestand.
    #>

    clear-host

    # Bestandslocatie van de tekstfile met mappenpaden
    $bestandslocatie = "Z:\scripting\settings\mappen.txt"
    $inhoud = Get-Content -Path $bestandslocatie -ErrorAction Stop

    foreach ($regel in $inhoud) 
    {
        $delen = $regel.Split("\")

        # Initialiseer een variabele om het huidige pad bij te houden
        $huidigPad = ""

        # Itereer over elk deel van het pad
        foreach ($deel in $delen) 
        {
            # Voeg het huidige deel toe aan het huidige pad
            $huidigPad += $deel + "\"

            # Controleer of het huidige pad bestaat
            if (-not (Test-Path $huidigPad)) 
            {
                try 
                {
                    # Als het niet bestaat, maak het dan aan
                    New-Item -Path $huidigPad -ItemType Directory | Out-Null
                    Write-Host "de map $huidigPad aangemaakt."
                    Log-Message "Map gemaakt: $huidigPad"
                } 
                catch 
                {
                    Write-Host "Error: Kon map $huidigPad niet aanmaken: $_"
                    Log-Message "ERROR: Fout bij het aanmaken van map $huidigPad : $_"
                }
            } 
            else 
            {
                Write-Host "map $huidigPad bestaad al."
            }
        }
    }

    Read-Host "druk op enter om voort te gaan."
}

Export-ModuleMember -Function mappenstructuur


function shares {
    <#
    .SYNOPSIS
        Deze functie maakt gedeelde mappen aan op basis van informatie uit een CSV-bestand.

    .DESCRIPTION
        Deze functie leest de pad- en share-informatie uit een CSV-bestand en maakt vervolgens de corresponderende gedeelde mappen aan met behulp van de New-SmbShare cmdlet.
        Als het pad al bestaat, wordt gecontroleerd of de share al bestaat. Als dat niet het geval is, wordt de share aangemaakt.
        Als het pad niet bestaat, wordt eerst het pad gemaakt, gevolgd door de creatie van de share.
        Alle acties worden gelogd naar een logbestand.

    .PARAMETER None
        Er zijn geen parameters nodig voor deze functie.

    .EXAMPLE
        shares
        Maakt de gedeelde mappen aan zoals gespecificeerd in het CSV-bestand en logt alle acties naar een logbestand.
    #>

    # Verwijder het consolevenster om de uitvoer schoon te houden
    Clear-Host

    # CSV-bestand met pad- en share-informatie importeren
    $sharespath = Import-Csv Z:\scripting\settings\shares.csv -Delimiter ';'

    # Pad naar het logbestand
    $logpad = "Z:\scripting\logs\installatielogXP.txt"

    # Loop door elk item in het CSV-bestand
    foreach ($lijn in $sharespath) 
    {
        # Construeer het testpad door de driveletter en de map te combineren
        $testpath = $lijn.drive_letter + ":" + $lijn.map

        # Controleer of het testpad bestaat
        if (Test-Path -Path $testpath) 
        {
            # Controleer of de share al bestaat
            $bestaandeshare = Get-SmbShare -Name $lijn.share -ErrorAction SilentlyContinue

            if ($bestaandeshare -eq $null) 
            {
                # Als de share niet bestaat, maak deze dan aan
                try 
                {
                    New-SmbShare -Name $lijn.share -Path $testpath | Out-Null
                    Write-Host "Share: $($lijn.share) aangemaakt"
                    Log-Message "Share gemaakt: $($lijn.share)"
                } 
                catch 
                {
                    Write-Host "Error bij aanmaken van share $($lijn.share): $_"
                    Log-Message "ERROR: Fout bij aanmaken van share $($lijn.share): $_"
                }
            } 
            else 
            {
                # Als de share al bestaat, controleer of het pad overeenkomt
                if ($bestaandeshare.Path -ne $testpath) 
                {
                    try 
                    {
                        # Als het pad niet overeenkomt, verwijder de share en maak deze opnieuw aan
                        Remove-SmbShare -Name $lijn.share -Confirm:$false
                        New-SmbShare -Name $lijn.share -Path $testpath | Out-Null
                        Write-Host "Share: $($lijn.share) opnieuw aangemaakt"
                        Log-Message "Share opnieuw aangemaakt: $($lijn.share)"
                    } 
                    catch 
                    {
                        Write-Host "Error bij heraanmaken van share $($lijn.share): $_"
                        Log-Message "ERROR: Fout bij heraanmaken van share $($lijn.share): $_"
                    }
                } 
                else 
                {
                    # Als het pad overeenkomt, geef een melding dat de share al bestaat
                    Write-Host "Share $($lijn.share) bestaat al"
                    Log-Message "Share $($lijn.share) bestaat al"
                }
            }
        } 
        else 
        {
            try 
            {
                # Als het pad niet bestaat, maak het dan aan
                New-Item -Path $testpath -ItemType Directory | Out-Null
                Write-Host "Pad bestaat niet, $($testpath) aangemaakt"
                Log-Message "Pad gemaakt: $testpath"

                # Maak de share aan
                New-SmbShare -Name $lijn.share -Path $testpath | Out-Null
                Write-Host "Share: $($lijn.share) aangemaakt"
                Log-Message "Share gemaakt: $($lijn.share)"
            } 
            catch 
            {
                Write-Host "Error bij aanmaken van pad of share $($lijn.share): $_"
                Log-Message "ERROR: Fout bij aanmaken van pad of share $($lijn.share): $_"
            }
        }
    }

    # Wacht op Enter om door te gaan
    Write-Host "Druk op Enter om door te gaan" -BackgroundColor Green
    Read-Host
}

Export-ModuleMember -Function shares