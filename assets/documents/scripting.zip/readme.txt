Aandachtspunten voor het script
Bestanden plaatsen
Zorg ervoor dat alle bestanden in een map genaamd "scripting" worden geplaatst. Zet deze map vervolgens op een schijf of volume met de driveletter Z. Hierdoor kan het script de benodigde paden vinden. In de toekomst wil ik dit aanpassen om het gebruik eenvoudiger te maken.

Herstarten bij bepaalde functies
Voor sommige functies is een herstart vereist. Ik heb een optie toegevoegd waarmee u kunt kiezen om direct of later te herstarten. Automatisch inloggen na een herstart is echter nog niet gelukt, dus dit is voorlopig ongewijzigd gebleven. Wel gaat het script automatisch verder waar het was gebleven na de herstart, zodat u niet handmatig het proces hoeft te hervatten.

Naam wijzigen
Het aanpassen van de naam werkt zowel op de server als op het werkstation.

Interfaces instellen
Het configureren van interfaces is uitsluitend mogelijk op de server. Daarom verzoek ik u om, indien nodig, op de tweede server en op het werkstation handmatig een IP-adres toe te wijzen aan de interfaces.

Gebruikers en functies
Het is mij nog niet gelukt om gebruikers in een functie op te nemen, omdat het script nog niet volledig af is. Wel maakt het script de benodigde mappen en shares aan voor de home directories en roaming profiles.

NTFS-rechten en groepen
NTFS-rechten zijn nog niet ingesteld, en gebruikers zijn nog niet aan groepen toegevoegd.

Conclusie
Dit is hoe ver ik ben gekomen met het script. Ik hoop dat deze aandachtspunten duidelijk zijn en u ondersteunen bij het gebruik ervan.