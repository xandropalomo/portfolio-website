﻿
#TO DO de naamgeving van alle functies aanpasssn

# Definieer het pad naar het script
$ScriptPath = "Z:\scripting\script.ps1"

# Definieer de naam van het registeritem
$RegistryKey = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run"

# Definieer de naam van de registerwaarde (je kunt deze aanpassen naar jouw voorkeur)
$RegistryValueName = "MijnScript"

# Definieer het commando om het script aan het register toe te voegen
$RegistryCommand = "New-ItemProperty -Path '$RegistryKey' -Name '$RegistryValueName' -Value '$ScriptPath' -PropertyType String -Force"

# Definieer het commando om het script uit het register te verwijderen
$RemoveRegistryCommand = "Remove-ItemProperty -Path '$RegistryKey' -Name '$RegistryValueName' -ErrorAction SilentlyContinue"

# Controleer of de registerkey bestaat, zo niet, maak deze aan
if (Test-Path -Path $RegistryKey) {
    # Voeg het script toe aan het opstartregister
    Invoke-Expression $RegistryCommand
}


Import-Module Z:\scripting\Log-Message.psm1
Import-Module Z:\scripting\submenus.psm1

do {
     Clear-Host # Als je de console wilt wissen voordat het menu wordt weergegeven, kun je Clear-Host hier gebruiken.
    
    # Weergave van het keuzemenu
    Write-Host "keuzemenu:"
    Write-Host "`t1. basisinstellingen"
    Write-Host "`t2. domain configuratie"
    Write-Host "`t3. mappen & shares"
    Write-Host "kies 0 om te stoppen"

    # Invoer van de gebruiker
    [int]$keuze = Read-Host "Wat wilt u instellen? (Voer het nummer van uw keuze in)"

    # Controleer of de invoer geldig is (tussen 0 en 3)
    if ($keuze -match '[0-3]') 
    {
        # Verwerk de keuze van de gebruiker met behulp van een switch
        switch ($keuze) 
        {
            1 { basisinstellingen }
            2 { domain_configuratie }
            3 { mappen_en_shares }
        }
    } 
    else 
    {
        Write-Host "Ongeldige keuze. De enige geldige keuzes zijn 1, 2, 3 en 0. press enter." -ForegroundColor Red
        Read-Host
    }
} 
while ($keuze -ne 0)

Invoke-Expression $RemoveRegistryCommand