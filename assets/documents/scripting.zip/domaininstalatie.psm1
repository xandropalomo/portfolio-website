﻿
function domaininstalatie 
{
    <#
    .SYNOPSIS
        Deze functie installeert een nieuw Active Directory-domein of voegt een computer toe aan een bestaand domein, afhankelijk van de Windows-editie.

    .DESCRIPTION
        Deze functie leest de instellingen uit een XML-bestand en controleert of de vereiste AD-Domain-Services-functie is geïnstalleerd. Als deze niet is geïnstalleerd, wordt deze geïnstalleerd.
        Vervolgens wordt gecontroleerd of het opgegeven domein al bestaat. Indien niet, wordt een nieuw domein aangemaakt met de opgegeven parameters uit het XML-bestand. Als het domein al bestaat, wordt een nieuwe domeincontroller toegevoegd aan het bestaande domein.
        Als de Windows-editie geen ServerStandard is, wordt de computer toegevoegd aan het opgegeven domein.
        Het script logt alle acties naar een logbestand.

    .PARAMETER restartkeuze
        Geeft aan of de computer automatisch moet worden herstart na de installatie.

    .EXAMPLE
        domaininstalatie -restartkeuze 'y' -password '***********'
        Installeert een nieuw domein of voegt een computer toe aan een bestaand domein, en start de computer automatisch opnieuw op.

    .EXAMPLE
        domaininstalatie -restartkeuze 'n' -password '***********'
        Installeert een nieuw domein of voegt een computer toe aan een bestaand domein, en vraagt om handmatige herstartverificatie.

    #>

    [cmdletbinding()]
    param (
        [parameter(mandatory=$true, helpmessage= "Wilt u automatisch herstarten? (y/n)")]
        [string]$restartkeuze, # Keuze om al dan niet automatisch opnieuw op te starten
        [parameter(mandatory=$true)]
        [securestring]$password # Wachtwoord voor de installatie
    )

    # Verwijder het consolevenster
    Clear-Host

    # Pad naar XML-bestand met instellingen
    $xmlpath =  "Z:\scripting\settings\instellingen.xml"

    # Pad naar het XML bestand met alle instellingen
    [xml]$xml = Get-Content -Path $xmlpath -ErrorAction Stop

    # Controleer of de AD-Domain-Services-feature is geïnstalleerd
    $featureInstalled = (Get-WindowsFeature -Name AD-Domain-Services).Installed

    if (-not $featureInstalled) 
    {
        # Als de feature niet is geïnstalleerd, geef een melding en installeer deze
        Write-Output "De AD-Domain-Services-feature inclusief beheerhulpprogramma's is nog niet geïnstalleerd."
        Install-WindowsFeature AD-Domain-Services -IncludeManagementTools | Out-Null

        # Logbericht toevoegen
        Log-Message "######    Domain Features    ######"
        Log-Message "AD-Domain-Services geïnstalleerd"
        Log-Message "######    Einde Domain Features    ######"
    } 
    else 
    {
        # Als de feature is geïnstalleerd, geef een melding
        Write-Output "De AD-Domain-Services-feature inclusief beheerhulpprogramma's is reeds geïnstalleerd."
    }

    # Controleren of het domein al bestaat
    $domainName = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "domein" }
    $forrestmode = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "forrestmode" }
    $domainmode = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "domeinmode" }
    
    try 
    {
        $existingDomain = Get-ADDomain -Identity $domainName.'#text' -ErrorAction SilentlyContinue
    } 
    catch 
    {
        Log-Message "Geen domein gevonden: $_"
    }
    
    $windowsedition = Get-WindowsEdition -Online

    if ($windowsedition.Edition -eq "ServerStandard") 
    {
        if (-not $existingDomain) 
        {
            # Als het domein niet bestaat, maak dan een nieuw domein aan
            Write-Output "Het domein bestaat nog niet. Een nieuw domein wordt aangemaakt."

            # Nieuw domein aanmaken
            try 
            {
                Install-ADDSForest -DomainName $domainName.'#text' -ForestMode $forrestmode.'#text' -DomainMode $domainmode.'#text' -NoRebootOnCompletion -SafeModeAdministratorPassword $password -Confirm:$false | Out-Null

                Write-Host "Domein aangemaakt. Computer wordt herstart in 10 seconden."

                # Logbericht toevoegen
                Log-Message "######    Domain Installatie    ######"
                Log-Message "Domein $($domainName.innertext) aangemaakt"
                Log-Message "######    Einde Domain Installatie    ######"
            } 
            catch 
            {
                Log-Message "ERROR: Fout bij het aanmaken van het domein: $_"
                return
            }
        } 
        else 
        {
            # Als het domein bestaat, voeg een nieuwe domeincontroller toe
            try 
            {
                $domaincredential = $($domainName.innertext).Split(".")
                $domaincredential = $domaincredential[0] + "\administrator"
                Install-ADDSDomainController -DomainName $domainName.innertext -InstallDns:$true -SafeModeAdministratorPassword $password -Credential (Get-Credential "$domaincredential") -NoRebootOnCompletion -Confirm:$false

                Write-Host "Domeincontroller toegevoegd aan bestaand domein. Computer wordt herstart in 10 seconden."

                # Logbericht toevoegen
                Log-Message "######    Domain Installatie    ######"
                Log-Message "Domeincontroller toegevoegd aan bestaand domein"
                Log-Message "######    Einde Domain Installatie    ######"
            } 
            catch 
            {
                Log-Message "ERROR: Fout bij het toevoegen van de domeincontroller: $_"
                return
            }
        }
    } 
    else 
    {
        try 
        {
            $domaincredential = $($domainName.innertext).Split(".")
            $domaincredential = $domaincredential[0] + "\administrator"
        
            Add-Computer -DomainName $domainName.innertext -Credential $domaincredential

            # Logbericht toevoegen
            Log-Message "######    Domain Installatie    ######"
            Log-Message "Computer toegevoegd aan het domein"
            Log-Message "######    Einde Domain Installatie    ######"
        } 
        catch 
        {
            Log-Message "ERROR: Fout bij het toevoegen van de computer aan het domein: $_"
            return
        }
    }

    # Controleren of opnieuw opstarten is ingesteld
    if ($restartkeuze -eq "y") 
    {
        Write-Host "De computer wordt nu opnieuw opgestart in 10 seconden."
        Start-Sleep -Seconds 10
        Restart-Computer
    } 
    elseif ($restartkeuze -eq "n") 
    {
        Write-Host "U zult handmatig moeten herstarten." -ForegroundColor Green
        Write-Host "Druk op Enter om door te gaan."
        Read-Host
    }
}

Export-ModuleMember -Function domaininstalatie


function ous-aanmaken {
    <#
    .SYNOPSIS
        Deze functie maakt Organizational Units (OU's) aan op basis van informatie uit een CSV-bestand.

    .DESCRIPTION
        Deze functie leest de OU-namen uit een CSV-bestand en maakt vervolgens de corresponderende OUs aan in Active Directory.
        Het script controleert of de Windows-editie ServerStandard is voordat het probeert de OUs aan te maken.
        Alle acties worden gelogd naar een logbestand.

    .PARAMETER None
        Er zijn geen parameters nodig voor deze functie.

    .EXAMPLE
        ous-aanmaken
        Maakt de OUs aan zoals gespecificeerd in het CSV-bestand en logt alle acties naar een logbestand.

    #>

    Clear-Host

    # Pad naar CSV-bestand met OU-namen
    $csvFilePath = "Z:\scripting\settings\ous.csv"

    # Pad naar XML-bestand met instellingen
    $xmlPath = "Z:\scripting\settings\instellingen.xml"
    [xml]$xml = Get-Content -Path $xmlPath -ErrorAction Stop

    $domainName = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "domein" }
    $domain = $domainName.InnerText.Split(".")

    # Probeer het CSV-bestand in te lezen
    $alleous = get-content $csvFilePath
    
    # Controleren of de Windows-editie ServerStandard is
    $windowsedition = Get-WindowsEdition -Online

    if ($windowsedition.Edition -eq "ServerStandard") 
    {
        foreach ($ouName in $alleous) 
        {
            $ouArray = $ouName.Split(".")
            [array]::Reverse($ouArray)
            $currentPath = ($domain | ForEach-Object { "dc=$_" }) -join ","

            foreach ($ou in $ouArray) 
            {
                $ouPath = "OU=$ou,$currentPath"
                try 
                {
                    $bestaandeou = Get-ADOrganizationalUnit -Filter "Name -eq '$ou'" -SearchBase $currentPath -ErrorAction SilentlyContinue
                    if ($bestaandeou -eq $null) 
                    {
                        # Nieuwe OU aanmaken als deze niet bestaat
                        New-ADOrganizationalUnit -Name $ou -Path $currentPath -ProtectedFromAccidentalDeletion $false
                        Write-Host "$ou aangemaakt in $currentPath"

                        # Logbericht toevoegen
                        Log-Message "OU gemaakt: $ou in $currentPath"
                    } 
                    else 
                    {
                        Write-Host "OU '$ou' bestaat al."
                    }
                } 
                catch 
                {
                    Write-Host "Error OU='$ou': $_ niet aangemaakt"
                    Log-Message "ERROR: Fout bij het aanmaken van OU '$ou' in $currentPath : $_"
                }
                $currentPath = $ouPath
            }
        }
    } 
    else 
    {
        Write-Host "Dit is geen server, dus kunnen er geen OUs worden aangemaakt."
        Log-Message "ERROR: Geen server-editie gedetecteerd. OUs kunnen niet worden aangemaakt."
    }

    # Wachten op Enter om door te gaan
    Read-Host "Druk op Enter om verder te gaan"
}

Export-ModuleMember -Function ous-aanmaken

function Goups-aanmaken {
    <#
    .SYNOPSIS
        Deze functie maakt groepen aan op basis van informatie uit een CSV-bestand en plaatst ze in de juiste Organizational Units (OUs) in Active Directory.

    .DESCRIPTION
        Deze functie leest de groepsinformatie uit een CSV-bestand en maakt vervolgens de corresponderende groepen aan in Active Directory. Het bepaalt de groepsscope (Global of Domain Local) op basis van de groepsnaam in het CSV-bestand.
        Voor elke groep wordt de bijbehorende OU gevonden en gebruikt om de groep te plaatsen.
        Alle acties worden gelogd naar een logbestand.

    .PARAMETER None
        Er zijn geen parameters nodig voor deze functie.

    .EXAMPLE
        Goups-aanmaken
        Maakt de groepen aan zoals gespecificeerd in het CSV-bestand en logt alle acties naar een logbestand.
    #>

    # Verwijder het consolevenster om de uitvoer schoon te houden
    Clear-Host

    # CSV-bestand met groepsinformatie importeren
    $groupfile = Import-Csv Z:\scripting\settings\groups.csv -Delimiter ';'

    # Pad naar XML-bestand met instellingen
    $xmlPath = "Z:\scripting\settings\instellingen.xml"

    # Pad naar logbestand
    $logPath = "Z:\scripting\logs\installatielogXP.txt"
    [xml]$xml = Get-Content -Path $xmlPath -ErrorAction Stop

    foreach ($lijn in $groupfile) 
    {
        # Bepaal de groepsscope op basis van de groepsnaam
        $groupscope = $($lijn.GroepNaam).Split("_")[0]
    
        if ($groupscope -eq "GL") 
        {
            $groupscope = "Global"
        } 
        elseif ($groupscope -eq "DL") 
        {
            $groupscope = "DomainLocal"
        }

        # Het domein ophalen uit het XML-bestand
        $domainName = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "domein" }
        $domain = $domainName.InnerText.Split(".")
        $domainpath = ($domain | ForEach-Object { "dc=$_" }) -join ","

        # De OU-pad(en) ophalen uit het CSV-bestand
        $grouppath = $lijn.ou

        foreach ($item in $grouppath) 
        {
            $ous =  $item.Split(".")
            $oupath = ($ous | ForEach-Object {"ou=$_"}) -join ','
        }
        $fullpath = $oupath + "," + $domainpath

        foreach ($ouName in $lijn.ou) 
        {
            $ouArray = $ouName.Split(".")
            [array]::Reverse($ouArray)
            $currentPath = ($domain | ForEach-Object { "dc=$_" }) -join ","

            foreach ($ou in $ouArray) 
            {
                $ouPath = "OU=$ou,$currentPath"
                try 
                {
                    $bestaandeou = Get-ADOrganizationalUnit -Filter "Name -eq '$ou'" -SearchBase $currentPath -ErrorAction SilentlyContinue
                    if ($bestaandeou -eq $null) 
                    {
                        # Nieuwe OU aanmaken als deze niet bestaat
                        New-ADOrganizationalUnit -Name $ou -Path $currentPath -ProtectedFromAccidentalDeletion $false
                        Write-Host "$ou aangemaakt in $currentPath"

                        # Logbericht toevoegen
                        Log-Message "OU gemaakt: $ou in $currentPath"
                    }
                } 
                catch 
                {
                    Write-Host "Error OU='$ou': $_ niet aangemaakt"
                    Log-Message "ERROR: Fout bij het aanmaken van OU '$ou' in $currentPath : $_"
                }
                $currentPath = $ouPath
            }
        }

        try 
        {
            # Groep aanmaken
            New-ADGroup -Name $lijn.groepnaam -GroupCategory Security -GroupScope $groupscope -Path $fullpath
            Write-Host "$lijn.groepnaam aangemaakt"
            Log-Message "Groep aangemaakt: $lijn.groepnaam in $fullpath"
        } 
        catch 
        {
            Write-Host "Error : $_"
            Log-Message "ERROR: Fout bij het aanmaken van groep $lijn.groepnaam in $fullpath : $_"
        }
    }

    # Wachten op Enter om door te gaan
    Write-Host "Druk op Enter om verder te gaan"
    Read-Host
}

# Exporteer de functie zodat deze beschikbaar is buiten dit script
Export-ModuleMember -Function Goups-aanmaken