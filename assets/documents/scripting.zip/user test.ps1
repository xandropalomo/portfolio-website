﻿
Clear-Host
$userfile = Import-Csv Z:\scripting\settings\Users.csv -Delimiter ';'
$xmlPath = "Z:\scripting\settings\instellingen.xml"
$logpad = "Z:\scripting\logs\installatielogXP.txt"
[xml]$xml = Get-Content $xmlPath


foreach ($user in $userfile)
{
    $userfolder = "c:\" + $user.homeshare
$userprofiles = "c:\" + $user.profielshare
$folders = @($userprofiles, $userfolder)

foreach ($testpath in $folders)
{
    $testpathsplit = $testpath.split(':')
    $name = $testpathsplit[1]
    if(Test-Path -Path $testpath)
        {
            $bestaandeshare = Get-SmbShare -Name $name -ErrorAction SilentlyContinue
        if ($bestaandeshare -eq $null)
        {
            New-SmbShare -Name $name -Path $testpath | Out-Null
            Write-Host "share: $($name) aangemaakt"
            $logbericht = "share gemaakt: $($name)    om" + $(Get-Date)
            Add-Content -Value $logbericht -Path $logpad
        }
        else
            {
                if ($bestaandeshare.Path -ne $testpath)
                    {
                        Remove-SmbShare -Name $name -Confirm:$false
                        New-SmbShare -Name $name -Path $testpath | Out-Null
                        Write-Host "share: $($name) aangemaakt"
                        $logbericht = "share gemaakt: $($name)    om" + $(Get-Date)
                        Add-Content -Value $logbericht -Path $logpad
                    }
                }
        }
        else
        {
            New-Item -Path $testpath -ItemType Directory | Out-Null
            Write-Host "pad bestaat niet, $($testpath) aangemaakt"
            $logbericht = "pad gemaakt: $testpath    om" + $(Get-Date)
            Add-Content -Value $logbericht -Path $logpad

            New-SmbShare -Name $name -Path $testpath | Out-Null
            Write-Host "share: $($name) aangemaakt"
            $logbericht = "share gemaakt: $($name)    om" + $(Get-Date)
            Add-Content -Value $logbericht -Path $logpad
        }
}


    $servernaam = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "servernaam" }
    $servernaamtext = $servernaam.'#text'
    $domainName = $xml.Objs.Obj.MS.S | Where-Object { $_.N -eq "domein" }
    $domain = $domainName.InnerText.Split(".")
    $domainpath = ($domain | ForEach-Object { "dc=$_" }) -join ","
    $oupath = $($user.ou).Split('.')
    [array]::Reverse($oupath)
    $oupath = ($oupath | ForEach-Object { "ou=$_" }) -join ","
    $oupath = $oupath + $domainpath
    $password = ConvertTo-SecureString $user.paswoord -AsPlainText -Force
    $profilepath = "\\$servernaamtext\$($user.profielshare)"
    $homepath = "\\$servernaamtext\$($user.homeshare)"
    $fullname = $user.voornaam + " " + $user.naam
    $homedrive = $user.homedrive + ":"
    
    $createuser = @{
        Name = $fullname 
        GivenName = $user.voornaam 
        Surname = $user.naam 
        SamAccountName = $user.loginnaam 
        Path = $oupath 
        AccountPassword = $password 
        ChangePasswordAtLogon = $false 
        PasswordNeverExpires = $true 
        ProfilePath = $profilepath 
        HomeDirectory = $homepath 
        HomeDrive = $homedrive
    }
    New-ADUser @createuser
    #Enable-ADAccount -Identity $user.loginnaam
}