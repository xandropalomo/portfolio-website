﻿
# TO DO als het z drive een ander drive letter is hoe lossen we dit op? relatief pad of Drive Letter megeven in de param blok

function Log-Message 
    {
        <#
            .SYNOPSIS
                Deze functie registreert berichten naar een logbestand met een timestamp.

         .DESCRIPTION
                De functie Log-Message accepteert een stringbericht als invoerparameter en schrijft dit bericht naar een opgegeven logbestand. Elk bericht wordt voorafgegaan door een timestamp in het formaat "yyyy-MM-dd HH:mm:ss". Het logbestand wordt opgeslagen op een gespecificeerde locatie.

         .PARAMETER message
                De tekst van het bericht dat moet worden gelogd. Dit moet een string zijn.

          .EXAMPLE
                Log-Message -message "Installatie succesvol voltooid."
                Logt het bericht "Installatie succesvol voltooid." met de huidige timestamp naar het logbestand.

            .EXAMPLE
                Log-Message -message "Fout: Kan verbinding met de database niet maken."
                Logt het foutbericht "Fout: Kan verbinding met de database niet maken." met de huidige timestamp naar het logbestand.

        #>
        param 
        (
            [string]$message
        )
        $logpath = "Z:\scripting\logs\installatielogXP.txt"
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Add-Content -Path $logpath -Value "$timestamp - $message"
    }
Export-ModuleMember Log-Message